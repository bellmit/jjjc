package com.taiji.job.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;

import java.io.IOException;

/**
 * @author: xiewh
 * @time: 2021/4/6 15:52
 */
@Slf4j
public class HttpUtils {
    /**
     * 使用apache的HttpClient发送http请求
     * @param url     请求URL
     * @param content   请求参数
     * @Author: WgRui
     * @Date: 2020/12/16
     * @return XML String
     */
    public static String httpCilentPost(String url, String content) throws IOException {

        // 获得Http客户端
        CloseableHttpClient httpClient = HttpClientBuilder.create().build();

        // 创建Post请求
        HttpPost httpPost = new HttpPost(url);

        // 将数据放入entity中
        StringEntity entity = new StringEntity(content, "UTF-8");
        httpPost.setEntity(entity);

        // 响应模型
        String result = null;
        CloseableHttpResponse response = null;

        try {

            //设置请求头
            //特别说明一下，此处为SOAP1.1协议
            //如果用的是SOAP1.2协议，改为："application/soap+xml;charset=UTF-8"
            httpPost.setHeader("Content-Type", "text/xml;charset=UTF-8");

            //命名空间+方法名
            //如为SOAP1.2协议不需要此项
            httpPost.setHeader("SOAPAction", "application/soap+xml;charset=UTF-8");

            // 由客户端执行(发送)Post请求
            response = httpClient.execute(httpPost);

            // 从响应模型中获取响应实体
            HttpEntity responseEntity = response.getEntity();

            log.info("响应ContentType为:" + responseEntity.getContentType());
            log.info("响应状态为:" + response.getStatusLine());

            if (responseEntity != null) {
                result = EntityUtils.toString(responseEntity);
                log.info("响应内容为:" + result);
            }
        } finally {
            // 释放资源
            if (httpClient != null) {
                httpClient.close();
            }
            if (response != null) {
                response.close();
            }

        }
        return result;

    }

    public static void main(String[] args) throws IOException {

        //请求地址
        String url = "http://www.webxml.com.cn/WebServices/RandomFontsWebService.asmx";

        //请求报文
        String content = "<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:web=\"http://WebXml.com.cn/\">\n"+
                "<soapenv:Header/>\n"+
                "<soapenv:Body>\n"+
                "<web:getChineseFonts>\n"+
                "<web:byFontsLength>5</web:byFontsLength>\n"+
                "</web:getChineseFonts>\n"+
                "</soapenv:Body>\n"+
                "</soapenv:Envelope>";

        //调用
        String result = httpCilentPost(url, content);
    }

}
